﻿using System;
namespace MongoDbDemo
{
    public class Customer
    {
        public string Name { get; set; }
        public int CusId { get; set; }
        public DateTime Subtime { get; set; }

    }
}