﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MongoDB.Driver;
using System.Configuration;

namespace MongoDbDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            string connStr = ConfigurationManager.AppSettings["MongoServerSettings"];
            MongoServer _server = MongoServer.Create(connStr);
            MongoDatabase _db = _server.GetDatabase("test");

            var collectionName = typeof(Customer).Name;

            var collection = _db.GetCollection<Customer>(collectionName);

            Customer customer = new Customer();
            customer.CusId = 2;
            customer.Name = "shit";
            customer.Subtime = DateTime.Now;

            collection.Insert(customer);

            Console.WriteLine(collection.Count());

            Console.ReadKey();
        }
    }
}
