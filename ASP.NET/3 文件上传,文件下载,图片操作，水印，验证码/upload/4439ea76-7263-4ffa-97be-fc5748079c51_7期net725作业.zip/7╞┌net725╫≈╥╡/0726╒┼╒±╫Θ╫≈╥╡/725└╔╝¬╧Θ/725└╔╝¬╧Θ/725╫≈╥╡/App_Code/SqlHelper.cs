﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace DAL层
{
   
    public static class SqlHelper
    {
        public static readonly string constr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
        public static int MyExecuteNonQuery(string sql, CommandType cmdtype, params SqlParameter[] pms)
        {
            using (SqlConnection sonn = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand(sql, sonn))
                {
                    cmd.CommandType = cmdtype;
                    cmd.Parameters.AddRange(pms);
                    sonn.Open();
                    return cmd.ExecuteNonQuery();
                }
            }
        }
        public static object MyExecuteScalar(string sql, CommandType cmdtype, params SqlParameter[] pms)
        {
            using (SqlConnection sonn = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand(sql, sonn))
                {
                    cmd.CommandType = cmdtype;
                    cmd.Parameters.AddRange(pms);
                    sonn.Open();
                    return cmd.ExecuteScalar();
                }
            }
        }
        public static SqlDataReader MyExecuteReader(string sql, CommandType cmdtype, params SqlParameter[] pms)
        {
            SqlConnection conn = new SqlConnection(constr);
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.CommandType = cmdtype;
                if (pms != null)
                {
                    cmd.Parameters.AddRange(pms);

                }
                try
                {
                    conn.Open();
                    return cmd.ExecuteReader(CommandBehavior.CloseConnection);
                }
                catch (Exception)
                {
                    conn.Close();
                    conn.Dispose();
                    throw;
                }

            }
        }
    }
}
