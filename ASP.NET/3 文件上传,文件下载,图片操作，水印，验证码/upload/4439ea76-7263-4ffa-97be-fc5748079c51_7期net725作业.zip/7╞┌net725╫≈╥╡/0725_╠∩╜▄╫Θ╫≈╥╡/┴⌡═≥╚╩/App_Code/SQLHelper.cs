﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

/// <summary>
///SQLHelper 的摘要说明
/// </summary>
public static class SQLHelper
{
    static readonly string connstr = "server=.;database=Itcast2013;user=sa;pwd=12345";
    public static object ExecuteScalar(string cmdtext, CommandType ct, params SqlParameter[] paras)
    {
        using (SqlConnection conn = new SqlConnection(connstr))
        {
            using (SqlCommand cmd = new SqlCommand(cmdtext, conn))
            {
                cmd.CommandType = ct;
                if (paras != null)
                {
                    cmd.Parameters.AddRange(paras);
                }
                conn.Open();
                object obj = cmd.ExecuteScalar();
                return obj;
            }
        }
    }
    public static int ExecuteNonQuery(string cmdtext, CommandType ct, params SqlParameter[] paras)
    {
        using (SqlConnection conn = new SqlConnection(connstr))
        {
            using (SqlCommand cmd = new SqlCommand(cmdtext, conn))
            {
                cmd.CommandType = ct;
                if (paras != null)
                {
                    cmd.Parameters.AddRange(paras);
                }
                conn.Open();
                int i = cmd.ExecuteNonQuery();
                return i;
            }
        }
    }
    public static SqlDataReader ExecuteReader(string cmdtext, CommandType ct, params SqlParameter[] paras)
    {
        SqlConnection conn = new SqlConnection(connstr);
        using (SqlCommand cmd = new SqlCommand(cmdtext, conn))
        {
            cmd.CommandType = ct;
            if (paras != null)
            {
                cmd.Parameters.AddRange(paras);
            }
            try
            {
                conn.Open();
                return cmd.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch (Exception)
            {
                conn.Close();
                conn.Dispose();
                throw;
            }

        }
    }
    public static DataTable ExecuteDataTable(string cmdtext, CommandType ct, params SqlParameter[] paras)
    {
        DataTable dt = new DataTable();
        using (SqlDataAdapter adapter = new SqlDataAdapter(cmdtext, connstr))
        {
            adapter.SelectCommand.CommandType = ct;
            if (paras != null)
            {
                adapter.SelectCommand.Parameters.AddRange(paras);
            }
            adapter.Fill(dt);
            return dt;
        }
    }
}