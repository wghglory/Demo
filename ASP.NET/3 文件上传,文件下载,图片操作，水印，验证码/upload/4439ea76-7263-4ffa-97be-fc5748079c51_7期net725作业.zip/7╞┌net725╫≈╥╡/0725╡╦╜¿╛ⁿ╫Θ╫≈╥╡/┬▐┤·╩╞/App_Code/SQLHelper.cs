﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

public class SQLHelper
{
    private static readonly string conStr = ConfigurationManager.ConnectionStrings["myConStr"].ConnectionString;

    public static int MyExecuteNonQuery(string sql, CommandType type, params SqlParameter[] arr)
    {
        //连接对象
        using (SqlConnection con = new SqlConnection(conStr))
        {
            using (SqlCommand cmd = new SqlCommand(sql, con))
            {
                //命令对象类型
                cmd.CommandType = type;
                if (arr != null)
                {
                    //添加命令对象的参数
                    cmd.Parameters.AddRange(arr);
                }
                //打开数据库连接
                con.Open();
                return cmd.ExecuteNonQuery();
                //cmd.ExecuteScalar
            }
        }
    }

    public static object MyExecuteScalar(string sql, CommandType type, params SqlParameter[] arr)
    {
        using (SqlConnection con = new SqlConnection(conStr))
        {
            using (SqlCommand cmd = new SqlCommand(sql, con))
            {
                if (arr != null)
                {
                    cmd.Parameters.AddRange(arr);
                }
                //打开数据库连接
                con.Open();
                return cmd.ExecuteScalar();
            }
        }
    }

    public static SqlDataReader MyExecuteReader(string sql, CommandType type, params SqlParameter[] arr)
    {
        SqlConnection con = new SqlConnection(conStr);

        using (SqlCommand cmd = new SqlCommand(sql, con))
        {
            if (arr != null)
            {
                cmd.Parameters.AddRange(arr);
            }
            try
            {
                con.Open();
                return cmd.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
            }
            catch
            {
                con.Close();
                con.Dispose();
                throw;
            }
        }
    }

    //返回DataTable
    public static DataTable MyExecuteDtaTable(string sql, CommandType type, params SqlParameter[] arr)
    {
        //创建要填充的内存表
        DataTable table = new DataTable();
        using (SqlDataAdapter adapter = new SqlDataAdapter(sql, conStr))
        {
            if (arr != null)
            {
                //查询的命令对象
                adapter.SelectCommand.Parameters.AddRange(arr);
            }
            //命令对象的类型
            adapter.SelectCommand.CommandType = type;
            //填充
            adapter.Fill(table);
        }
        return table;
    }
}
