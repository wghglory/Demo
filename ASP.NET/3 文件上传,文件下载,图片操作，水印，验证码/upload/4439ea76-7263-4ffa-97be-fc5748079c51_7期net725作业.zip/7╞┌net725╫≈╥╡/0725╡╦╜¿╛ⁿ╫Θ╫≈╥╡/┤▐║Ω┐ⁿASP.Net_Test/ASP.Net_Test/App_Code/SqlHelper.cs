﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public static class SqlHelper
    {
        public readonly static string strConn = ConfigurationManager.ConnectionStrings["sweetConn"].ConnectionString;
        public static int ExecuteNonQuery(string sql, CommandType type = CommandType.Text, params SqlParameter[] pas)
        {
            using (SqlConnection conn = new SqlConnection(strConn))
            {
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    if (pas != null) { cmd.Parameters.AddRange(pas); }
                    cmd.CommandType = type;
                    conn.Open();
                    int result = cmd.ExecuteNonQuery();
                    cmd.Parameters.Clear();
                    return result;
                }
            }
        }
        //=====================================
        public static object ExecuteScalar(string sql, CommandType type = CommandType.Text, params SqlParameter[] pas)
        {
            using (SqlConnection conn = new SqlConnection(strConn))
            {
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    if (pas != null) { cmd.Parameters.AddRange(pas); }
                    cmd.CommandType = type;
                    conn.Open();
                    object result = cmd.ExecuteScalar();
                    cmd.Parameters.Clear();
                    return result;
                }
            }
        }
        //=====================================
        public static SqlDataReader ExecuteReader(string sql, CommandType type = CommandType.Text, params SqlParameter[] pas)
        {
            SqlConnection conn = new SqlConnection(strConn);
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                if (pas != null) { cmd.Parameters.AddRange(pas); }
                cmd.CommandType = type;
                try
                {
                    conn.Open();
                    SqlDataReader result = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                    cmd.Parameters.Clear();
                    return result;
                }
                catch
                {
                    conn.Close();
                    throw;
                }
            }
        }

    }
}
