﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace 省市加载
{
    public static class SqlHelper
    {
        private static readonly string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;

        //返回
        public static int ExecuteNonQuery(string sql, CommandType cmdType, params SqlParameter[] pams)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.CommandType = cmdType;
                    if (pams != null)
                    {
                        cmd.Parameters.AddRange(pams);
                    }
                    conn.Open();
                    return cmd.ExecuteNonQuery();
                }
            }
        }

        //返回一个值的方法
        public static object ExecuteScalar(string sql, CommandType cmdType, params SqlParameter[] pams)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.CommandType = cmdType;
                    if (pams != null)
                    {
                        cmd.Parameters.AddRange(pams);
                    }
                    conn.Open();
                    return cmd.ExecuteScalar();
                }
            }
        }

        //放回一个SqlDataReader的方法
        public static SqlDataReader ExecuteReader(string sql, CommandType cmdType, params SqlParameter[] pams)
        {
            SqlConnection conn = new SqlConnection(connStr);
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.CommandType = cmdType;
                if (pams != null)
                {
                    cmd.Parameters.AddRange(pams);
                }
                try
                {
                    conn.Open();
                    return cmd.ExecuteReader(CommandBehavior.CloseConnection);
                }
                catch
                {
                    conn.Close();
                    conn.Dispose();
                    throw;
                }
            }
        }

        //返回一个DataTable的方法
        public static DataTable ExecuteDataTable(string sql, CommandType cmdType, params SqlParameter[] pams)
        {
            DataTable dt = new DataTable();
            using (SqlDataAdapter adapter = new SqlDataAdapter(sql, connStr))
            {
                adapter.SelectCommand.CommandType = cmdType;
                if (pams != null)
                {
                    adapter.SelectCommand.Parameters.AddRange(pams);
                }
                adapter.Fill(dt);
            }
            return dt;
        }
    }
}
