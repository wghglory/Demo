﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// User 的摘要说明
/// </summary>
public class User
{
	public User()
	{
		//
		// TODO: 在此处添加构造函数逻辑
		//
	}
    private int _autoId;
    public int AutoId
    {
        get { return _autoId; }
        set { _autoId = value; }
    }
    private string _loginId;
    public string LoginId
    {
        get { return _loginId; }
        set { _loginId = value; }
    }
    private string _loginPwd;
    public string LoginPwd
    {
        get { return _loginPwd; }
        set { _loginPwd = value; }
    }
    private int? _errorCount;
    public int? ErrorCount
    {
        get { return _errorCount; }
        set { _errorCount = value; }
    }
    private DateTime? _lastLoginTime;
    public DateTime? LastLoginTime
    {
        get { return _lastLoginTime; }
        set { _lastLoginTime = value; }
    }


}