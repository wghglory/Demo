﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace Person.DAL
{
    public static class SqlHelper
    {
        //从配置文件中获取连接字符串
        public static string connString = ConfigurationManager.ConnectionStrings["conString"].ConnectionString;
        public static object ExecuteScalar(string comString, params SqlParameter[] parms)
        {
            using (SqlConnection con = new SqlConnection(connString))
            {
                using (SqlCommand com = new SqlCommand(comString, con))
                {
                    com.Parameters.AddRange(parms);
                    con.Open();
                    return com.ExecuteScalar();
                }
            }
        }

        public static int ExecuteNonQuery(string comString, params SqlParameter[] parms)
        {
            using (SqlConnection con = new SqlConnection(connString))
            {
                using (SqlCommand com = new SqlCommand(comString, con))
                {
                    com.Parameters.AddRange(parms);
                    con.Open();
                    return com.ExecuteNonQuery();
                }
            }
        }
        public static SqlDataReader ExecuteReader(string comString, params SqlParameter[] parms)
        {
            SqlConnection con = new SqlConnection(connString);
            using (SqlCommand com = new SqlCommand(comString, con))
            {
                com.Parameters.AddRange(parms);
                con.Open();
                try
                {
                    return com.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
                }
                catch
                {
                    con.Close();
                    throw;
                }

            }
        }


    }
}

